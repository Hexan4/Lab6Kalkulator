﻿namespace ASP.NETLab1.Models
{
    public class Calculator
    {
        public int liczba1 { get; set; }

        public int liczba2 { get; set; }

        public string znak { get; set; }
    }
}
